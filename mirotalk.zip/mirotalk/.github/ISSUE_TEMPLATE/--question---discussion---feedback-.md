---
name: "\U0001F64BQuestion - discussion - feedback."
about: Anything not related to bugs or features request.
title: ''
labels: ''
assignees: ''

---

# MiroTalk forum

If you have `ideas, suggestions, questions, doubts` about MiroTalk or `need support`, please use the MiroTalk Forum instead:

👉 [https://discord.gg/rgGYfeYW3N](https://discord.gg/rgGYfeYW3N)
