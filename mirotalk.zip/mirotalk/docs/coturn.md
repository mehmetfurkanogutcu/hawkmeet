# Install Coturn STUN/TURN server

### What are STUN and TURN in the context of network communication?

[https://docs.mirotalk.com/coturn/stun-turn/](https://docs.mirotalk.com/coturn/stun-turn/)

### How can I set up and configure my own STUN and TURN servers?

[https://docs.mirotalk.com/coturn/installation/](https://docs.mirotalk.com/coturn/installation/)

---
